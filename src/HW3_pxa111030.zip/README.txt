For problems 11.11, 11.12, and 11.13:
	HW3_11_13's test program is a single class file per the professor's announcement.
	Additionally, all relevant methods are contained within the ArrayListUtils file